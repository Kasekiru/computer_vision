import os
import pandas as pd
import cv2
import numpy as np
from sklearn.metrics import precision_score, recall_score, f1_score

def compare_images_with_folder(reference_image_path, folder_path):
    similarities = []
    precision_scores = []
    recall_scores = []
    f1_scores = []

    # Load reference image and extract SIFT features
    reference_image = cv2.imread(reference_image_path)
    gray_ref = cv2.cvtColor(reference_image, cv2.COLOR_BGR2GRAY)
    sift = cv2.SIFT_create()
    keypoints_ref, descriptors_ref = sift.detectAndCompute(gray_ref, None)

    # Prepare a list to hold images with keypoints drawn
    images_with_keypoints = []

    for idx, filename in enumerate(os.listdir(folder_path)):
        if filename.endswith(".png") or filename.endswith(".jpg"):
            image_path = os.path.join(folder_path, filename)
            # Load the current image
            current_image = cv2.imread(image_path)
            gray = cv2.cvtColor(current_image, cv2.COLOR_BGR2GRAY)

            # Extract SIFT features for the current image
            keypoints, descriptors = sift.detectAndCompute(gray, None)

            # Perform feature matching using descriptors
            bf = cv2.BFMatcher()
            matches = bf.knnMatch(descriptors_ref, descriptors, k=2)

            # Filter matches using Lowe's ratio test
            good_matches = []
            for m, n in matches:
                if m.distance < 0.75 * n.distance:
                    good_matches.append(m)

            # Calculate precision, recall, and F1-score
            matches_mask = np.zeros(len(good_matches))
            for i, match in enumerate(good_matches):
                matches_mask[i] = 1 if match.distance < 0.75 * n.distance else 0

            precision = precision_score(np.ones(len(matches_mask)), matches_mask)
            recall = recall_score(np.ones(len(matches_mask)), matches_mask)
            f1 = f1_score(np.ones(len(matches_mask)), matches_mask)

            precision_scores.append(precision)
            recall_scores.append(recall)
            f1_scores.append(f1)

            # Calculate similarity percentage
            similarity_percentage = len(good_matches) / len(keypoints_ref) * 100
            similarities.append(similarity_percentage)

            # Draw SIFT keypoints on the current image
            image_with_keypoints = cv2.drawKeypoints(current_image, keypoints, None)
            images_with_keypoints.append(image_with_keypoints)

    # Display all images with keypoints drawn
    for idx, img_with_keypoints in enumerate(images_with_keypoints):
        cv2.imshow(f"Image{idx + 1} with Keypoints", img_with_keypoints)

    cv2.waitKey(0)
    cv2.destroyAllWindows()

    # Save metrics to Excel file
    data = {'Image': [f'Image{i + 1}' for i in range(len(images_with_keypoints))],
            'Similarity (%)': similarities,
            'Precision': precision_scores,
            'Recall': recall_scores,
            'F1-score': f1_scores}
    df_metrics = pd.DataFrame(data)
    df_metrics.to_excel('image_metrics.xlsx', index=False)

# Load reference image
reference_image_path = 'Soal 5\\cat1.png'

# Folder path containing images to compare with the reference image
folder_path = 'Soal 5\\dataset'

# Compare images within the folder
compare_images_with_folder(reference_image_path, folder_path)
