import numpy as np
import cv2
import pandas as pd

def grayscale(image):
    img = cv2.imread(image)
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, binary_img = cv2.threshold(gray_img, 127, 255, cv2.THRESH_BINARY)
    return gray_img, binary_img

def dilate(image, kernel):
    result = cv2.dilate(image, kernel, iterations=1)
    return result

def erode(image, kernel):
    result = cv2.erode(image, kernel, iterations=1)
    return result

def opening(image, kernel):
    result = cv2.morphologyEx(image, cv2.MORPH_OPEN, kernel)
    return result

def closing(image, kernel):
    result = cv2.morphologyEx(image, cv2.MORPH_CLOSE, kernel)
    return result

def convert_to_binary(image):
    return np.where(image == 255, 1, 0)

img_path = 'Soal 4\\cat.png'
gray_img, binary_img = grayscale(img_path)

kernel_size = (3, 3)
kernel = np.ones(kernel_size, dtype=np.uint8)

# Process the images
dilated_img = dilate(binary_img, kernel)
eroded_img = erode(binary_img, kernel)
opened_img = opening(binary_img, kernel)
closed_img = closing(binary_img, kernel)

# Convert images to binary
binary_img_binary = convert_to_binary(binary_img)
dilated_img_binary = convert_to_binary(dilated_img)
eroded_img_binary = convert_to_binary(eroded_img)
opened_img_binary = convert_to_binary(opened_img)
closed_img_binary = convert_to_binary(closed_img)

# Convert binary arrays to DataFrame
df_gray = pd.DataFrame(gray_img)
df_binary = pd.DataFrame(binary_img_binary)
df_dilated = pd.DataFrame(dilated_img_binary)
df_eroded = pd.DataFrame(eroded_img_binary)
df_opened = pd.DataFrame(opened_img_binary)
df_closed = pd.DataFrame(closed_img_binary)

# Write DataFrames to Excel file
with pd.ExcelWriter('segmentation.xlsx') as writer:
    df_gray.to_excel(writer, sheet_name='Gray', index=False, header=False)
    df_binary.to_excel(writer, sheet_name='Binary', index=False, header=False)
    df_dilated.to_excel(writer, sheet_name='Dilated', index=False, header=False)
    df_eroded.to_excel(writer, sheet_name='Eroded', index=False, header=False)
    df_opened.to_excel(writer, sheet_name='Opened', index=False, header=False)
    df_closed.to_excel(writer, sheet_name='Closed', index=False, header=False)

print("Excel file 'segmentation.xlsx' saved with binary calculations and original grayscale values.")
