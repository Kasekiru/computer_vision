import cv2
import numpy as np
import pandas as pd

def fill_holes(binary_image):
    # Inversi citra biner (putih menjadi hitam dan sebaliknya)
    inverted_image = cv2.bitwise_not(binary_image)
    
    # Temukan kontur dari citra terinversi
    contours, _ = cv2.findContours(inverted_image, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    
    # Jika tidak ada kontur yang ditemukan, kembalikan citra biner asli
    if not contours:
        return binary_image
    
    # Buat citra kosong untuk menyimpan area yang diisi (kontur diisi)
    filled_image = np.zeros_like(binary_image)
    
    # Gambar ulang semua kontur yang ditemukan untuk mengisi area dalam citra
    cv2.drawContours(filled_image, contours, -1, 255, thickness=cv2.FILLED)
    
    # Inversi kembali citra untuk mendapatkan hasil pengisian lubang
    filled_image = cv2.bitwise_not(filled_image)
    
    return filled_image

# Baca citra (pastikan citra adalah citra biner, misalnya hasil dari dilasi dan erosi)
input_image = cv2.imread('Soal 4\\cat.png', cv2.IMREAD_GRAYSCALE)

# Lakukan thresholding untuk mengubah citra ke citra biner
_, binary_image = cv2.threshold(input_image, 100, 255, cv2.THRESH_BINARY)

# Lakukan pengisian lubang (filling holes)
filled_image = fill_holes(binary_image)

# Tampilkan citra asli
cv2.imshow('Original Image', input_image)

# Tampilkan citra setelah pengisian lubang
cv2.imshow('Filled Image', filled_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Convert images to DataFrame
df_before = pd.DataFrame(binary_image)
df_after = pd.DataFrame(filled_image)

# Write DataFrames to Excel file
with pd.ExcelWriter('fill_holes.xlsx') as writer:
    df_before.to_excel(writer, sheet_name='Before', index=False, header=False)
    df_after.to_excel(writer, sheet_name='After', index=False, header=False)

print("Excel file 'fill_holes.xlsx' saved with before and after images.")
