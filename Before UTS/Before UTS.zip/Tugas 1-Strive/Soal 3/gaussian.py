import cv2
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def apply_gaussian_blur(image, kernel_size=(5, 5), sigma_x=0):
    blurred_image = cv2.GaussianBlur(image, kernel_size, sigma_x)
    return blurred_image

# Load gambar
image = cv2.imread('C:\\Users\\frynn\\OneDrive\\Desktop\\Kode Comp Vis\\Soal 3\\cat.png')

# Cek apakah gambar berhasil dimuat
if image is None:
    print("Gagal membaca gambar!")
else:
    # Konversi gambar ke grayscale jika perlu
    if len(image.shape) > 2:
        grayscale_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    else:
        grayscale_image = image
    
    # Terapkan Gaussian blur
    blurred_image = apply_gaussian_blur(grayscale_image)

    try:
        # Simpan hasil perhitungan ke dalam file Excel
        df_original = pd.DataFrame(grayscale_image)
        df_blurred = pd.DataFrame(blurred_image)

        with pd.ExcelWriter('gaussian_blur_output.xlsx') as writer:
            df_original.to_excel(writer, sheet_name='Original Image', index=False, header=False)
            df_blurred.to_excel(writer, sheet_name='Blurred Image', index=False, header=False)

        print("Hasil perhitungan telah disimpan ke dalam file 'gaussian_blur_output.xlsx'.")

        # Tampilkan gambar asli dan hasil blur
        plt.figure(figsize=(10, 5))
        plt.subplot(1, 2, 1)
        plt.imshow(grayscale_image, cmap='gray')
        plt.title('Original Image')
        plt.axis('off')

        plt.subplot(1, 2, 2)
        plt.imshow(blurred_image, cmap='gray')
        plt.title('Blurred Image')
        plt.axis('off')

        plt.show()

    except Exception as e:
        print("Terjadi kesalahan:", e)
