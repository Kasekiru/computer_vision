import cv2
import numpy as np

# Read the image
image = cv2.imread('Soal 3\\cat.png', cv2.IMREAD_GRAYSCALE)

# Apply Sobel operator
sobelx = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)
sobely = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)

# Compute the gradient magnitude
gradient_magnitude = np.sqrt(sobelx**2 + sobely**2)

# Set a threshold to binarize the gradient magnitude image
threshold = 6
edges = np.uint8(gradient_magnitude > threshold) * 255

# Display the result
cv2.imshow('Original Image', image)
cv2.imshow('Edges (Sobel)', edges)
cv2.waitKey(0)
cv2.destroyAllWindows()
