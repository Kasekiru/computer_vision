import cv2
import numpy as np

# Read the image
image = cv2.imread('Soal 3\\cat.png', cv2.IMREAD_GRAYSCALE)

# Apply Prewitt operator
kernel_x = np.array([[-1, 0, 1],
                     [-1, 0, 1],
                     [-1, 0, 1]])

kernel_y = np.array([[-1, -1, -1],
                     [ 0,  0,  0],
                     [ 1,  1,  1]])

prewittx = cv2.filter2D(image, -1, kernel_x)
prewitty = cv2.filter2D(image, -1, kernel_y)

# Compute the gradient magnitude
gradient_magnitude = np.sqrt(prewittx**2 + prewitty**2)

# Set a threshold to binarize the gradient magnitude image
threshold = 11
edges = np.uint8(gradient_magnitude > threshold) * 255

# Display the result
cv2.imshow('Original Image', image)
cv2.imshow('Edges (Prewitt)', edges)
cv2.waitKey(0)
cv2.destroyAllWindows()
