import cv2
import numpy as np
import pandas as pd
from openpyxl import Workbook
from openpyxl.drawing.image import Image as ExcelImage

# Fungsi untuk melakukan sharpening dengan memperhitungkan batas gambar
def sharpening_with_border_handling(image, kernel):
    # Ukuran gambar
    height, width = image.shape[:2]
    # Ukuran kernel
    k_height, k_width = kernel.shape[:2]

    # Inisialisasi matriks output
    output = np.zeros((height, width), dtype=np.uint8)

    # Perhitungan batas
    border_x = k_width // 2
    border_y = k_height // 2

    # Looping untuk setiap piksel di dalam gambar
    for y in range(border_y, height - border_y):
        for x in range(border_x, width - border_x):
            # Mendapatkan area piksel yang akan disharpening
            roi = image[y - border_y:y + border_y + 1, x - border_x:x + border_x + 1]
            # Melakukan sharpening pada area tersebut
            conv_result = np.sum(roi * kernel)
            # Membatasi nilai menjadi 0-255
            output[y, x] = np.clip(conv_result, 0, 255)

    return output

# Matriks sharpening untuk peningkatan kontras (15x15)

image_sharpen_3x3 = np.array([
    [0,-1,0],
    [-1,5,-1],
    [0,-1,0]
])

# Load gambar
image = cv2.imread('Soal 1\\dataset\\cat.png', cv2.IMREAD_GRAYSCALE)

if image is not None:
    # Proses sharpening untuk peningkatan kontras
    contrast_enhanced_image = sharpening_with_border_handling(image, image_sharpen_3x3)
    # Simpan gambar grayscale
    cv2.imwrite('grayscale.png', image)
    print("Gambar grayscale berhasil disimpan sebagai 'grayscale.png'.")
    # Simpan gambar yang telah ditingkatkan kontras
    cv2.imwrite('download_contrast_enhanced.png', contrast_enhanced_image)
    print("Gambar berhasil ditingkatkan kontras dan disimpan sebagai 'download_contrast_enhanced.png'.")

    # Buat workbook baru
    wb = Workbook()
    ws = wb.active

    # Masukkan gambar ke dalam Excel
    img = ExcelImage('download_contrast_enhanced.png')
    ws.add_image(img, 'A1')

    # Simpan workbook
    wb.save('hasil.xlsx')
    print("Hasil gambar telah diekspor ke dalam Excel sebagai 'hasil.xlsx'.")
    result = sharpening_with_border_handling(image, image_sharpen_3x3)

    print("\nMatriks hasil sharpening:")
    print(result.astype(np.uint8))

    # cv2_imshow(result.astype(np.uint8))

    df_before = pd.DataFrame(image)
    df_after = pd.DataFrame(result)

    with pd.ExcelWriter('output.xlsx') as writer:
        df_before.to_excel(writer, sheet_name='Before sharpening', index=False, header=False)
        df_after.to_excel(writer, sheet_name='After sharpening', index=False, header=False)
else:
    print("Gagal membaca gambar 'cat.png'. Pastikan gambar tersedia di path yang benar.")

