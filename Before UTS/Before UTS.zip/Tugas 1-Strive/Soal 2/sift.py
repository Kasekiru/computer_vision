import cv2
import pandas as pd

# Load gambar
image = cv2.imread('C:\\Users\\frynn\\OneDrive\\Desktop\\Kode Comp Vis\\Soal 4\\cat.png')
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Inisialisasi detektor SIFT
sift = cv2.SIFT_create()

# Temukan titik kunci dan deskripsinya
keypoints, descriptors = sift.detectAndCompute(gray, None)

# Membuat DataFrame untuk menyimpan posisi titik kunci
keypoints_data = []
for kp in keypoints:
    keypoints_data.append([kp.pt[0], kp.pt[1]])

df_keypoints = pd.DataFrame(keypoints_data, columns=['X', 'Y'])

# Simpan DataFrame ke dalam file Excel
df_keypoints.to_excel('keypoints_data.xlsx', index=False)

print("Data titik kunci telah disimpan ke dalam 'keypoints_data.xlsx'.")

# Gambar titik kunci pada gambar input
image_with_keypoints = cv2.drawKeypoints(image, keypoints, None)

# Tampilkan gambar dengan titik kunci
cv2.imshow("Image with Keypoints", image_with_keypoints)
cv2.waitKey(0)
cv2.destroyAllWindows()
