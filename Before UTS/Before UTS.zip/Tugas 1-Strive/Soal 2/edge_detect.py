import cv2
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def convolution_with_border_handling(image, kernel):
    height, width = image.shape[:2]
    k_height, k_width = kernel.shape[:2]

    output = np.zeros((height, width))

    border_x = k_width // 2
    border_y = k_height // 2

    for y in range(border_y, height - border_y):
        for x in range(border_x, width - border_x):
            roi = image[y - border_y:y + border_y + 1, x - border_x:x + border_x + 1]
            conv_result = np.sum(roi * kernel)
            output[y, x] = min(conv_result, 255)

    return output

edge_detection_3x3 = np.array([
   [-1,-1,-1],
   [-1,8,-1],
   [-1,-1,-1]
])

image = cv2.imread('C:\\Users\\frynn\\OneDrive\\Desktop\\Kode Comp Vis\\Soal 2\\cat.png', cv2.IMREAD_GRAYSCALE)

if image is None:
    print("Gagal membaca gambar!")
else:
    result = convolution_with_border_handling(image, edge_detection_3x3)

    # Normalisasi hasil deteksi tepi
    result = cv2.normalize(result, None, 0, 255, cv2.NORM_MINMAX)

    # Thresholding
    _, result = cv2.threshold(result.astype(np.uint8), 163, 255, cv2.THRESH_BINARY)

    df_before = pd.DataFrame(image)
    df_after = pd.DataFrame(result)

    with pd.ExcelWriter('output.xlsx') as writer:
        df_before.to_excel(writer, sheet_name='Before Edge Detection', index=False, header=False)
        df_after.to_excel(writer, sheet_name='After Edge Detection', index=False, header=False)

    # Tampilkan gambar hasil edge detection
    plt.imshow(result, cmap='gray')
    plt.title('Hasil Edge Detection')
    plt.axis('off')
    plt.show()
