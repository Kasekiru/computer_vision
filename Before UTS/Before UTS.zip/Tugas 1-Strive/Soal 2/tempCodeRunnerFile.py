import cv2

# Load gambar
image = cv2.imread('C:\\Users\\frynn\\OneDrive\\Desktop\\Kode Comp Vis\\Soal 4\\cat.png')
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Inisialisasi detektor SIFT
sift = cv2.xfeatures2d.SIFT_create()

# Temukan titik kunci dan deskripsinya
keypoints, descriptors = sift.detectAndCompute(gray, None)

# Gambar titik kunci pada gambar input
image_with_keypoints = cv2.drawKeypoints(image, keypoints, None)

# Tampilkan gambar dengan titik kunci
cv2.imshow("Image with Keypoints", image_with_keypoints)
cv2.waitKey(0)
cv2.destroyAllWindows()
