Path dalam kode masih harus diubah agar kode bisa jalan dengan baik. Setiap soal memiliki foldernya tersendiri dan semua hal yang akan digunakan itu sebatas folder itu saja. Agar menginput image yang ingin diproses ke dalam kode:
- Klik kanan "cat.png" dan save relative path
- Paste path ke bagiannya tersendiri
Setiap kode akan memunculkan satu atau lebih file excel di folder terluar dan mungkin dapat di-overwrite karena nama file soal lain mungkin sama.